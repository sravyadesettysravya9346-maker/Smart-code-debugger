import { useState } from 'react';
import { Bug, BookOpen } from 'lucide-react';
import CodeEditor from './components/CodeEditor';
import ErrorDisplay from './components/ErrorDisplay';
import SolutionSuggestions from './components/SolutionSuggestions';
import DebuggingHistory from './components/DebuggingHistory';
import type { ErrorAnalysis } from './types';

function App() {
  const [code, setCode] = useState('');
  const [analysis, setAnalysis] = useState<ErrorAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  const analyzeCode = async () => {
    if (!code.trim()) return;

    setIsAnalyzing(true);
    setAnalysis(null);

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const response = await fetch(`${supabaseUrl}/functions/v1/analyze-code`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseAnonKey}`,
        },
        body: JSON.stringify({ code, language: 'python' }),
      });

      if (!response.ok) {
        throw new Error('Failed to analyze code');
      }

      const result = await response.json();
      setAnalysis(result);
    } catch (error) {
      console.error('Error analyzing code:', error);
      alert('Failed to analyze code. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-600 rounded-lg">
                <Bug className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  Smart Code Debugger
                </h1>
                <p className="text-gray-600 mt-1">
                  Your AI-powered coding mentor for beginners
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors"
            >
              <BookOpen className="w-5 h-5" />
              {showHistory ? 'Hide History' : 'Show History'}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <CodeEditor
              code={code}
              onChange={setCode}
              onAnalyze={analyzeCode}
              isAnalyzing={isAnalyzing}
            />

            {analysis && (
              <>
                <ErrorDisplay analysis={analysis} />
                <SolutionSuggestions analysis={analysis} />
              </>
            )}
          </div>

          <div className="lg:col-span-1">
            {showHistory && <DebuggingHistory />}

            {!showHistory && (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">
                  How It Works
                </h3>
                <ol className="space-y-3 text-sm text-gray-700">
                  <li className="flex gap-2">
                    <span className="font-semibold text-blue-600">1.</span>
                    <span>Paste or type your Python code in the editor</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold text-blue-600">2.</span>
                    <span>Click "Analyze Code" to detect errors</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold text-blue-600">3.</span>
                    <span>Read the clear explanation of what went wrong</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold text-blue-600">4.</span>
                    <span>Review the suggested fix and corrected code</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold text-blue-600">5.</span>
                    <span>Learn from your mistakes and improve!</span>
                  </li>
                </ol>

                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <h4 className="font-semibold text-gray-800 mb-2">
                    Common Errors We Detect:
                  </h4>
                  <ul className="space-y-1 text-sm text-gray-700">
                    <li>• Syntax Errors</li>
                    <li>• Indentation Errors</li>
                    <li>• Missing Colons</li>
                    <li>• Unclosed Strings</li>
                    <li>• Unmatched Parentheses</li>
                    <li>• Invalid Print Syntax</li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <footer className="mt-12 py-6 text-center text-gray-600 text-sm">
        <p>Smart Code Debugger - Helping beginners learn to code, one error at a time</p>
      </footer>
    </div>
  );
}

export default App;
