export interface ErrorAnalysis {
  hasError: boolean;
  errorType: string;
  errorMessage: string;
  explanation: string;
  suggestedFix: string;
  fixedCode: string;
  lineNumber?: number;
  sessionId?: string;
}

export interface DebuggingSession {
  id: string;
  user_id: string | null;
  code_input: string;
  language: string;
  error_type: string | null;
  error_message: string | null;
  explanation: string | null;
  suggested_fix: string | null;
  fixed_code: string | null;
  created_at: string;
}

export interface CommonError {
  id: string;
  error_pattern: string;
  language: string;
  title: string;
  description: string;
  solution: string;
  examples: string | null;
  created_at: string;
}
