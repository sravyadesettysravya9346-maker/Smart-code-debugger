import { Copy, Check, Lightbulb } from 'lucide-react';
import { useState } from 'react';
import type { ErrorAnalysis } from '../types';

interface SolutionSuggestionsProps {
  analysis: ErrorAnalysis | null;
}

export default function SolutionSuggestions({ analysis }: SolutionSuggestionsProps) {
  const [copied, setCopied] = useState(false);

  if (!analysis || !analysis.hasError) {
    return null;
  }

  const handleCopy = async () => {
    await navigator.clipboard.writeText(analysis.fixedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center gap-3 mb-4">
        <Lightbulb className="w-6 h-6 text-yellow-600" />
        <h2 className="text-xl font-semibold text-gray-800">Suggested Solution</h2>
      </div>

      <p className="text-gray-600 mb-4">
        Here's a corrected version of your code. Review the changes and learn from the fix:
      </p>

      <div className="relative">
        <button
          onClick={handleCopy}
          className="absolute top-3 right-3 p-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
          title="Copy to clipboard"
        >
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        </button>

        <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
          <code className="font-mono text-sm">{analysis.fixedCode}</code>
        </pre>
      </div>

      <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <p className="text-sm text-gray-700">
          <strong>Learning Tip:</strong> Compare your original code with the fixed version to understand what went wrong and how to avoid similar errors in the future.
        </p>
      </div>
    </div>
  );
}
