import { Code, Play } from 'lucide-react';

interface CodeEditorProps {
  code: string;
  onChange: (code: string) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
}

export default function CodeEditor({ code, onChange, onAnalyze, isAnalyzing }: CodeEditorProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Code className="w-5 h-5 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-800">Code Input</h2>
        </div>
        <button
          onClick={onAnalyze}
          disabled={isAnalyzing || !code.trim()}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
        >
          <Play className="w-4 h-4" />
          {isAnalyzing ? 'Analyzing...' : 'Analyze Code'}
        </button>
      </div>

      <textarea
        value={code}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Paste your Python code here..."
        className="w-full h-96 p-4 font-mono text-sm bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
        spellCheck={false}
      />

      <div className="mt-2 text-sm text-gray-600">
        <p>Enter your Python code and click "Analyze Code" to detect errors and get suggestions.</p>
      </div>
    </div>
  );
}
