import { History, Clock } from 'lucide-react';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { DebuggingSession } from '../types';

export default function DebuggingHistory() {
  const [sessions, setSessions] = useState<DebuggingSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSessions();
  }, []);

  const fetchSessions = async () => {
    try {
      const { data, error } = await supabase
        .from('debugging_sessions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setSessions(data || []);
    } catch (error) {
      console.error('Error fetching sessions:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <History className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-800">Recent Sessions</h2>
        </div>
        <p className="text-gray-600">Loading...</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center gap-3 mb-4">
        <History className="w-6 h-6 text-blue-600" />
        <h2 className="text-xl font-semibold text-gray-800">Recent Sessions</h2>
      </div>

      {sessions.length === 0 ? (
        <p className="text-gray-600">No debugging sessions yet. Start analyzing code to see your history!</p>
      ) : (
        <div className="space-y-3">
          {sessions.map((session) => (
            <div
              key={session.id}
              className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-start justify-between mb-2">
                <span className={`px-2 py-1 text-xs font-medium rounded ${
                  session.error_type === 'None'
                    ? 'bg-green-100 text-green-700'
                    : 'bg-red-100 text-red-700'
                }`}>
                  {session.error_type}
                </span>
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <Clock className="w-3 h-3" />
                  {formatDate(session.created_at)}
                </div>
              </div>

              <p className="text-sm text-gray-700 line-clamp-2">
                {session.error_message}
              </p>

              <div className="mt-2">
                <pre className="text-xs bg-gray-100 p-2 rounded overflow-x-auto line-clamp-2">
                  <code>{session.code_input}</code>
                </pre>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
