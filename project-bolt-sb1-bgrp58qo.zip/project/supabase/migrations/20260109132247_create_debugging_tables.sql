/*
  # Smart Code Debugger Assistant - Database Schema

  1. New Tables
    - `debugging_sessions`
      - `id` (uuid, primary key) - Unique identifier for each debugging session
      - `user_id` (uuid, nullable) - Optional user identification for future auth
      - `code_input` (text) - The code submitted by the user
      - `language` (text) - Programming language (default: 'python')
      - `error_type` (text) - Type of error detected (syntax, runtime, logic, etc.)
      - `error_message` (text) - Detailed error message
      - `explanation` (text) - Human-readable explanation of the error
      - `suggested_fix` (text) - Suggested solution to fix the error
      - `fixed_code` (text, nullable) - Corrected code example
      - `created_at` (timestamptz) - Timestamp of session creation
    
    - `common_errors`
      - `id` (uuid, primary key) - Unique identifier
      - `error_pattern` (text) - Pattern or signature of the error
      - `language` (text) - Programming language
      - `title` (text) - Short title of the error
      - `description` (text) - Detailed description
      - `solution` (text) - How to fix it
      - `examples` (text) - Code examples
      - `created_at` (timestamptz) - Timestamp
  
  2. Security
    - Enable RLS on both tables
    - Allow public read access to common_errors (educational resource)
    - Allow anyone to insert debugging_sessions (for anonymous users)
    - Allow users to read their own debugging_sessions
*/

CREATE TABLE IF NOT EXISTS debugging_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  code_input text NOT NULL,
  language text DEFAULT 'python',
  error_type text,
  error_message text,
  explanation text,
  suggested_fix text,
  fixed_code text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS common_errors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  error_pattern text NOT NULL,
  language text NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  solution text NOT NULL,
  examples text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE debugging_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE common_errors ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert debugging sessions"
  ON debugging_sessions FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can read their own sessions"
  ON debugging_sessions FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can read common errors"
  ON common_errors FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS idx_debugging_sessions_created_at ON debugging_sessions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_common_errors_language ON common_errors(language);