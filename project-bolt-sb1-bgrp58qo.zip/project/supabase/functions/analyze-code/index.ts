import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface AnalyzeRequest {
  code: string;
  language?: string;
}

interface ErrorAnalysis {
  hasError: boolean;
  errorType: string;
  errorMessage: string;
  explanation: string;
  suggestedFix: string;
  fixedCode: string;
  lineNumber?: number;
}

function analyzePythonCode(code: string): ErrorAnalysis {
  const lines = code.split('\n');
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const lineNum = i + 1;
    
    if (/^\s*(if|elif|else|for|while|def|class|try|except|finally|with)\s+.*[^:]$/.test(line) && !line.trim().endsWith(':')) {
      return {
        hasError: true,
        errorType: 'SyntaxError',
        errorMessage: `Missing colon at end of statement on line ${lineNum}`,
        explanation: `In Python, control structures like if, for, while, def, class, etc. must end with a colon (:). This tells Python that a new code block is starting.`,
        suggestedFix: `Add a colon at the end of line ${lineNum}`,
        fixedCode: code.split('\n').map((l, idx) => idx === i ? l + ':' : l).join('\n'),
        lineNumber: lineNum
      };
    }
    
    if (/^(if|elif|for|while|def|class|try|except|finally|with)\s/.test(line.trim()) && i + 1 < lines.length) {
      const nextLine = lines[i + 1];
      if (nextLine.trim() && !/^\s/.test(nextLine)) {
        return {
          hasError: true,
          errorType: 'IndentationError',
          errorMessage: `Expected an indented block after line ${lineNum}`,
          explanation: `Python uses indentation (spaces) to define code blocks. After statements like if, for, while, def, the next line must be indented. Use 4 spaces for each indentation level.`,
          suggestedFix: `Indent the code on line ${lineNum + 1} with 4 spaces`,
          fixedCode: code.split('\n').map((l, idx) => idx === i + 1 ? '    ' + l : l).join('\n'),
          lineNumber: lineNum + 1
        };
      }
    }
    
    const unclosedStrings = (line.match(/"/g) || []).length % 2 !== 0 || (line.match(/'/g) || []).length % 2 !== 0;
    if (unclosedStrings && !line.includes('#')) {
      return {
        hasError: true,
        errorType: 'SyntaxError',
        errorMessage: `Unclosed string on line ${lineNum}`,
        explanation: `Every opening quote must have a matching closing quote. Python strings can use single quotes ('text') or double quotes (\"text\"), but they must match.`,
        suggestedFix: `Add a closing quote on line ${lineNum}`,
        fixedCode: code,
        lineNumber: lineNum
      };
    }
    
    const unclosedParens = (line.match(/\(/g) || []).length !== (line.match(/\)/g) || []).length;
    const unclosedBrackets = (line.match(/\[/g) || []).length !== (line.match(/\]/g) || []).length;
    const unclosedBraces = (line.match(/\{/g) || []).length !== (line.match(/\}/g) || []).length;
    
    if (unclosedParens || unclosedBrackets || unclosedBraces) {
      return {
        hasError: true,
        errorType: 'SyntaxError',
        errorMessage: `Unmatched parentheses, brackets, or braces on line ${lineNum}`,
        explanation: `Every opening parenthesis (, bracket [, or brace { must have a matching closing symbol ), ], or }. Check that all pairs are properly closed.`,
        suggestedFix: `Add the missing closing symbol on line ${lineNum}`,
        fixedCode: code,
        lineNumber: lineNum
      };
    }
    
    if (/print\s+[^(]/.test(line) && !line.includes('print(')) {
      return {
        hasError: true,
        errorType: 'SyntaxError',
        errorMessage: `Invalid print syntax on line ${lineNum}`,
        explanation: `In Python 3, print is a function and requires parentheses. You must write print(\"text\") instead of print \"text\".`,
        suggestedFix: `Change print statement to use parentheses: print(...)`,
        fixedCode: code.replace(/print\s+([^(].*)/, 'print($1)'),
        lineNumber: lineNum
      };
    }
  }
  
  return {
    hasError: false,
    errorType: 'None',
    errorMessage: 'No errors detected',
    explanation: 'Your code syntax looks good! However, this is a basic check. You may still encounter runtime errors when executing the code.',
    suggestedFix: 'Try running your code to check for runtime errors.',
    fixedCode: code
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { code, language = 'python' }: AnalyzeRequest = await req.json();

    if (!code || code.trim() === '') {
      return new Response(
        JSON.stringify({ error: 'Code input is required' }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const analysis = analyzePythonCode(code);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { data: session, error: dbError } = await supabase
      .from('debugging_sessions')
      .insert({
        code_input: code,
        language: language,
        error_type: analysis.errorType,
        error_message: analysis.errorMessage,
        explanation: analysis.explanation,
        suggested_fix: analysis.suggestedFix,
        fixed_code: analysis.fixedCode,
      })
      .select()
      .single();

    if (dbError) {
      console.error('Database error:', dbError);
    }

    return new Response(
      JSON.stringify({
        ...analysis,
        sessionId: session?.id,
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error analyzing code:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to analyze code', details: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});